
package MyPack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DBmaneger {
    Connection con=null;
    PreparedStatement pd=null;
    ResultSet rs=null;
    public DBmaneger()
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
         catch(Exception ex)   
                 {
                 }
        }
    //code for connection
    public Connection getCon()
    {
        try
        {
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project23","root","");
            return con;
        }
        catch(Exception ex)
        {
        }
        return con;
    }
    //end code for connection
    //code for insertupdatedelete method
    public boolean MyInsertUpdateDelete(String command)
    {
        try
        {
            pd=getCon().prepareStatement(command);
            pd.executeUpdate(command);
            return true;
        }
        catch(Exception astha)
        {
            return false;
        }
    }
    //end code for insertdeleteupdate
    //code for display record
    public ResultSet DisplayAllRecords(String command)
    {
        try
        {
            pd=getCon().prepareStatement(command);
            rs=pd.executeQuery(command);
            return rs;
        }
        catch(Exception ex)
        {
            
        }
        return rs;
    }
    //end code for display record
}